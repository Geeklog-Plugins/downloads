# Changelog

## 1.4.0 — development branch (feature scope frozen 2026-11-03)

- Fix intermittent undefined `DLM_createSafeFileName()` in Item Info callbacks by explicitly loading Downloads filename helpers; add a targeted dependency regression check.
- Confirmed by project owner: successful upgrade from 1.3.2 and functional acceptance of the redesigned public interface (2026-11-03).
- Defer previously planned new period statistics, release synchronization/review queue and project history to 1.4.1; no automatic publishing or storage migration in this release.

- Replace legacy green default category/download arrow artwork with a neutral folder SVG matching the default download image; simplify category link markup and align icon sizes without affecting custom category snapshots.

- Redesign individual download pages with responsive compact metadata, thumbnail/default image, prominent download action, full-width description and release notes, and a separated checksum/actions footer. Retain existing project history, extensions, and comments.

- Add a configurable default image URL for missing download snapshots (#9), shipping a neutral SVG; use it in list and detail views without lightbox and register the new setting on upgrade.

- Rebuild public listing templates around semantic responsive cards (with and without thumbnails), removing the duplicated Downloads heading and obsolete float-based layout; replace the earlier catalog CSS overrides with a dedicated, scoped layout.

- Refresh public Downloads directory with responsive software-catalog cards, category navigation, search, sorting controls, thumbnails and prominent download buttons; preserve existing actions and URLs.

- Provide separate short-description and full-details fields for GitHub Release proposals, matching the existing two-field model of standard Downloads submissions. Preserve complete GitHub release notes in the native moderation `detail` field up to a validated 60,000-byte limit; avoid silent 3,500-byte truncation, and preview full notes.

- Exempt Downloads editors (`downloads.edit`) from the GitHub proposal limit of five submissions per rolling 24 hours; keep the limit for regular users and distinguish quota errors from invalid submissions.

- Render GitHub release Markdown in the administrative submission and download preview using the same safe renderer as public download pages; retain normal GLText previews for non-GitHub downloads.

- Versioned the installable distribution as Downloads 1.4.0.
- Excluded the `tests/` directory from the distributed ZIP while retaining the test scripts in GitHub and CI.
- Added packaging validation that rejects archives containing tests.


## 1.3.2 — in development

- Fix admin preview with no image taking up only the left grid column; description and details can use full width.
- Prevent admin fieldsets from overflowing and restore compact, inline publication date selectors (including Japanese locale).

- Added authenticated GitHub Release submission with URL preview (direct tag links and release-page anchors), selectable ZIP asset, native moderation queue, duplicate detection and pending-submission history.
- Fetch GitHub archives only on approval with bounded transfer, ZIP validation, controlled staging and failure rollback; both admin and core moderation paths supported.
- Preserve original GitHub notes as Markdown and render descriptions and details as restricted, escaped HTML on published GitHub Downloads pages.
- Improved responsive GitHub submission forms, confirmation/duplicate notifications and consistent administrator submission workflow.
- Manually validated GitHub preview, submit, approve, ZIP retrieval, publication and error/rollback scenarios on Geeklog 2.2.2/PHP 8.1 (g2); older version integration remains untested.
- **Multisite/storage caveat:** legacy defaults still use `path_html/downloads_data`; per-site directory isolation is not automatic when sites share a filesystem root. No automatic migration is included.


- Read-only inventory now reports missing referenced files and accounts for legacy pending filenames.

- Display the existing blank-image fallback and disable snapshot/lightbox links when the original snapshot or its thumbnail is missing.

- Added a Root-only, read-only storage inventory for published downloads, pending uploads, snapshots and thumbnails. Lists potential orphan candidates without deleting files.

- Strengthened comment visibility for released downloads in enabled, readable categories.
- Handle oversized upload requests rejected by PHP `post_max_size` for administrator and user submissions.
- Avoid missing `$_FILES` name warnings on rejected uploads.
- Added PHP lint CI for the 1.3.2 development branch and a downloadable 1.3.2 development ZIP.


## 1.3.1 — in development

- Fixed timezone-dependent pending upload filenames: new submissions use epoch-based names.
- Restored approval of 1.3.0 and legacy pending uploads created under a different PHP timezone, with ambiguity protection.
- Improved pending-file lookup diagnostics.
- Fixed PHP undefined-array-key warning when deleting a download without a `page` POST parameter.
- Moved the submission preview above the validation editor for clearer moderation.
- Preserve authoritative original ZIP and snapshot filenames during approval, including filenames with commas or accented characters, so published image URLs match the uploaded files.
- Fix pending submission image preview using the actual temporary snapshot filename across current and legacy storage schemes.
- Allow identical snapshots to be shared between downloads, preserve existing published images during rollback, and remove duplicate temporary snapshots after successful approval.
- Replace misleading upload error messages that always referenced `error.log`: direct users to Geeklog logs instead, and clarify the generic finalization error.
- Distribution archive: `downloads_1.3.1_2.1.2.zip` (generated by GitHub Actions).


## 1.3.0 — 2026-10-08

GitHub release tag: `v1.3.0` (planned; not yet published).

### Compatibility

- Minimum Geeklog version is 2.1.2.
- Maintained PHP baseline is PHP 5.6 through PHP 8.1.
- Added CI linting on PHP 5.6, PHP 8.1 and PHP 8.3.

### Submission and approval

- Fixed undefined category-permission properties in submission editing/preview.
- Load category ACLs before checking access to a pending submission.
- Unified filesystem finalization for admin and Geeklog moderation approval paths.
- Roll back failed moderation approvals to the pending queue.
- Added durable Pending / Published / Rejected submission status history.
- Added a user-menu “My Downloads” submission-history page.
- Added configurable new-submission notification email.
- Kept submitter approval notification as a separate option.
- Added matching HTML/plaintext Geeklog email templates for submission and approval notifications.

### Uploads and file integrity

- Create/validate configured storage directories before upload.
- Use collision-safe pending filenames while retaining legacy pending-file compatibility.
- Treat an existing upload destination as an error instead of a false success.
- Roll back uploaded/finalized files when database persistence fails.
- Made published-file replacement failure-safe and keep the old file until the UPDATE succeeds.
- Added admin diagnostics for missing published files.
- Added missing/unwritable storage warning.
- Validate uploaded snapshot/category images as actual JPEG/PNG/GIF content.
- Restrict image chooser hints to image MIME types.
- Missing physical downloads now return a 404 instead of an empty response.

### SEO and public pages

- Added the Downloads landing page and public categories to XMLSitemap through Geeklog's native sitemap collection API.

- Added Meta Description and Meta Keywords to downloads, submissions and categories.
- Added public metadata output for category and download pages.
- Added real 404 handling for invalid download IDs, categories and out-of-range pages.
- Added permission-aware public Downloads search with category scope.
- Added image lightbox on listing/detail thumbnails.
- Improved Project Name suggestions and title-derived default.
- Added Tags field guidance and required-field indicators.

### Interoperability

- Corrected the Geeklog 2.2.2 `plugin_idToURL_downloads($sub_type, $item_id)` signature; the previous one-argument signature could prevent XMLSitemap incremental updates from removing old entries and cause duplicate URLs.
- Added stable root/category identities and normalized multi-resource Item Info metadata.
- Added sitemap URL de-duplication and language-aware category discovery.
- Added category lifecycle events and public `PLG_itemDisplay()` extension points.
- Routed page metadata through Geeklog's `PLG_getMetaTags()` cooperation layer when enabled.

- Hardened `plugin_getiteminfo_downloads()` to expose only public/released items.
- Added collection options for `since`, `limit` and `order`.
- Added deterministic `plugin_idtourl_downloads()` fallback.
- Retained `PLG_itemSaved()` / `PLG_itemDeleted()` lifecycle integration.
- Improved XMLSitemap / IndexNow compatibility.

### Administration

- Final form alignment now uses the same grid for fields, Access Rights and action buttons.

- Fixed Access Rights alignment by restructuring permission help inside the permissions field.
- Moved the required-field note out of the Category Image block.
- Improved category image upload/preview alignment and responsive admin form sizing.
- Aligned form action buttons with the same field grid used by the editors.
- Moved Access Rights inside the same administration layout container to remove horizontal drift.

- Expanded Preview from Description/Detail only to a representative download card with title, category, file metadata, project, homepage, image and content.
- Refined the administration form layout with responsive two-column field alignment and cleaner section spacing.

- Moved Meta Description and Meta Keywords directly below Detail in the download editor.
- Organized the download and category editors into logical General / Content & SEO / Media / Publication sections.
- Added an administration summary for total, published, unreleased, hidden, missing-file and pending-submission counts.
- Added compact visual status indicators for publication and file health.
- Added file counts and enabled/disabled status to the category administration list.
- Added category, publication-status and file-health filters to the download administration list.
- Replaced the legacy bulk category enable/disable POST behavior with a targeted per-category toggle.
- Added CSRF/Root enforcement to category moves/toggles and CSRF checks to submission approval/rejection and category creation.
- Hardened category-image preview against invalid image dimensions.
- Versioned plugin-owned CSS and JavaScript URLs with the 1.3.0 release version to prevent stale browser caches.

- Search now covers title, ID, project and version.
- Added publication/listing status column.
- Added file-health column.
- Added pending-submission count/link.
- Added native Geeklog configuration tooltips for important settings.

### Security and stabilization

- Made the multilingual SQL helper alias-aware so interoperability queries using category alias `c` no longer generate invalid `b.cid` references during XMLSitemap-triggered plugin configuration saves.
- Removed generic global `ROOTID` usage in favor of `DLM_ROOTID`.
- Encapsulated Downloads runtime configuration loading to avoid leaking generic temporary variables into the global scope.

- Multisite-safe storage migration remains deferred until functional stabilization is validated; intermediate 1.3.0 builds do not move existing storage.

- Qualified joined SEO columns in the download editor query to avoid MySQL ambiguous-column errors after adding category SEO metadata.

- Restored CSRF protection to public download rating.
- Ratings and download-history pages now enforce public item visibility.
- Fixed zero-vote rating initialization.
- Fixed feed update `$limit` variable handling.
- Removed obsolete duplicated approval file-move helpers.
- Hardened thumbnail generation for PHP 8/GdImage and invalid image sources.
- Fixed missing globals and empty-result handling in Geeklog callbacks.
- Load authoritative download/category ACLs before deletion.

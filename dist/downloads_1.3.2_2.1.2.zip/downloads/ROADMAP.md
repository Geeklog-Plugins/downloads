# Downloads development roadmap

## Next maintenance cycle: 1.3.2

**Status:** implementation started; fixes require automated CI and functional regression tests before release.

**Baseline:** Downloads 1.3.1, including successful manual tests of regular-user submission, Preview, approval through moderation and Downloads administration, email notifications, and identical shared snapshots on Geeklog 2.2.2. PHP 5.6/8.1/8.3 syntax CI passed; this does **not** constitute full functional verification of older Geeklog installations.

### 1.3.2 proposed priorities

1. **P0 — Uploaded-file diagnostics and data integrity**
   - [x] Avoid undefined `$_FILES['newfile']['name']` access when PHP drops a request.
   - [x] Detect a discarded HTTP POST exceeding `post_max_size` and display upload-size error in Downloads admin and submission callbacks (static implementation; browser-level regression still pending).
   - [ ] Investigate upstream [#8](https://github.com/Geeklog-Plugins/downloads/issues/8): enforce `upload_max_filesize`, `post_max_size`, `UPLOAD_ERR_*`, empty `$_POST` and server-size errors; display actionable, localized messages; clean failed partial uploads without touching published files.
   - [ ] Audit real delete/replace paths for orphaned ZIPs and thumbnails; distinguish shared snapshots and retained historical files.
   - [x] Add a **read-only** Root-admin storage inventory showing references to published and pending files, image files and thumbnails, and up to 100 unreferenced candidates per directory (initial version; no deletion).
   - [x] Report missing references and up to 100 missing filenames per storage folder, with legacy pending filenames resolved without false missing counts.
   - [ ] Add duplicate-content detection and manual cross-checks of old upload formats.
   - [ ] Confirm [#3](https://github.com/Geeklog-Plugins/downloads/issues/3) is fixed for **legacy** submissions on geeklog.net before requesting closure. 1.3.1 addresses timezone-dependent names and shared snapshots; do not assume every old upload format has been tested.
2. **P1 — Authorization and moderation correctness**
   - [x] Tighten `plugin_commentenabled_downloads()` to require a published download and enabled category; retain SQL read-permission filtering (initial correction for #22; end-to-end permission tests still pending).
   - [ ] Re-audit [#22](https://github.com/Geeklog-Plugins/downloads/issues/22): `plugin_commentenabled_downloads()` must apply effective item **and category** visibility and avoid leaking comment availability to unauthorized readers. Add anonymous/member/owner tests.
   - [ ] Re-check approval failure feedback and Geeklog's global moderation “Approved N items” counter: core reports an attempted approval even when Downloads has rolled the file back. Document core/plugin integration options; avoid misleading success claims.
   - [ ] Regression-test [#25](https://github.com/Geeklog-Plugins/downloads/issues/25) Preview ACL fix (addressed in 1.3.0, issue still open), including new, existing and pending downloads.
3. **P2 — Metadata and presentation**
   - [ ] Re-test [#24](https://github.com/Geeklog-Plugins/downloads/issues/24) on current XMLSitemap/IndexNow with create/edit/delete; diagnose the origin of any empty URL events before closing.
   - [ ] Verify [#19](https://github.com/Geeklog-Plugins/downloads/issues/19) real 404 handling for invalid file/category IDs and pagination on public routes (implemented in 1.3.0, issue still open).
   - [ ] Verify [#21](https://github.com/Geeklog-Plugins/downloads/issues/21) HTML/plaintext template notifications (implemented in 1.3.0, issue still open).
   - [ ] Verify [#1](https://github.com/Geeklog-Plugins/downloads/issues/1) admin new-submission email option (implemented in 1.3.0, issue still open).
   - [x] Preserve blank-image fallback without lightbox when a snapshot or thumbnail is physically missing (initial #9 robustness fix).
   - [ ] Record design proposal for [#9](https://github.com/Geeklog-Plugins/downloads/issues/9) optional default image; keep existing public layout.
   - [ ] Triage [#15](https://github.com/Geeklog-Plugins/downloads/issues/15) File Manager migration leftovers as legacy housekeeping, separate from any deletion feature.

### Issue inventory (upstream, checked 2026-10-16)

Ten open issues on `Geeklog-Plugins/downloads`: **#25, #24, #22, #21, #19, #15, #9, #8, #3, #1**. “Open” is a GitHub state, **not proof a defect remains**. Issues #1, #19, #21, #25 and substantial parts of #3 have corresponding changes in 1.3.0/1.3.1; validate on current deployments, then propose closing with test evidence. Do not close upstream issues without confirmation from maintainers.

### P0 — GitHub Releases importer (moved from 1.4.0)

**Required for 1.3.2 acceptance; implementation and functional tests pending.** This is a deliberately bounded, manually triggered administrative workflow, not unattended synchronization.

- [x] Validate the public GitHub release URL (`https://github.com/OWNER/REPO/releases/tag/TAG`) before metadata API calls, with redirects disabled (implementation pending tests).
- [x] Add PHP 5.6-compatible GitHub Releases API metadata reader and Root-only, CSRF-protected read-only preview of title, tag, date, notes and ZIP assets (implementation pending CI and browser test). No archive transfer or publication yet.
- [ ] Allow an administrator to choose one ZIP asset and prefill an **editable, unpublished** Downloads form, including title, version, description, source URL and category. Never auto-publish.
- [ ] Download the selected release asset through a bounded, validated server-side transfer to **temporary** local storage. Validate scheme/host and redirects against SSRF, HTTP status, content size, extension, resulting bytes, collisions, and optional checksums; use the regular Downloads finalization flow after confirmation.
- [ ] Enforce Downloads administrative permission and Geeklog CSRF tokens on fetch, import and confirmation; sanitize imported Markdown/HTML to the site's permitted content subset.
- [ ] Preserve existing entries and files on import failures; clean only the new temporary files and provide actionable errors for missing assets, failed network requests, rate limits and invalid responses.
- [ ] Detect already-imported releases before confirmation (stable GitHub repository/release identifiers or a documented equivalent), and offer a reviewable update path instead of silently creating duplicates.
- [ ] Add tests for multiple assets, no ZIP assets, prereleases, oversized responses, redirects, network timeouts, duplicate releases and failure rollback; include PHP 5.6 / 8.1 / 8.3 compatibility checks.
- [ ] Verify the workflow on g2, review package manifest and documentation, and obtain maintainer review before any tag.

**Explicitly deferred to 1.4.0:** scheduled update checks, automatic publication, multi-provider imports, and a broader project/release history data-model migration. A stable project listing remains a design requirement for subsequent versions; 1.3.2 must not silently alter existing URLs or counters.

### Release acceptance for 1.3.2

- [ ] Reproduce and document each targeted bug before making a behavioral change.
- [ ] Test create/edit/replacement/deletion, admin and regular-user moderation, identical/different snapshot name collisions, rollback and old pending uploads.
- [ ] Test files with spaces, punctuation and non-ASCII names; verify broken and unavailable snapshots are handled gracefully.
- [ ] Test errors for empty upload, PHP size limit (including `post_max_size` exceeded with empty `$_POST`), permissions and disk write failures.
- [ ] Validate with Geeklog 2.2.2 and PHP 8.1, run PHP 5.6/8.1/8.3 syntax checks, and explicitly note untested historical installations.
- [ ] Produce release ZIP via Actions and inspect manifest; keep version/package metadata aligned before PR.
- [ ] Obtain maintainer review prior to release.

## Planned feature cycle: 1.4.0 — release synchronization and project history

The manual GitHub Releases importer is now a **1.3.2 release requirement** (see P0 above). Version 1.4.0 is reserved for opt-in review queues for newer releases, durable project-to-release history, and possible additional release providers. No unattended publication.

### Deliberate non-goals

No automatic filesystem deletion, no unattended external release publication, and no automatic replacement of existing downloads. The 1.3.2 release should remain a focused corrective release.

---

## Historical 1.3.0 implementation status

Implemented in the development branch:

- storage directory validation/creation before uploads;
- failure-safe replacement of existing download files;
- fixed submission ACL initialization for `editsubmission`;
- shared file finalization for admin and Geeklog moderation approvals;
- rollback to pending state when moderation file finalization fails;
- durable submission status history: Pending / Published / Rejected;
- configurable moderator email notification for new submissions;
- `My Downloads` user-menu page ordered by submission date;
- download/category Meta Description and Meta Keywords;
- public SEO metadata and real 404 handling;
- image-only upload hints plus server-side JPEG/PNG/GIF validation;
- required-field indicators;
- Project Name suggestions and title-derived default;
- Tags field guidance;
- image lightbox on listings and detail pages;
- permission-aware public search with category scope;
- improved admin search, status visibility and pending-submission navigation;
- admin file-health and storage diagnostics;
- hardened Item Info for released/public content;
- XMLSitemap collection now includes the Downloads landing page, public categories and public downloads;
- richer Preview rendering with title/category/file/version/size/project/homepage/image/content;
- deterministic ID-to-URL fallback for IndexNow/XMLSitemap lifecycle consumers;
- public rating CSRF protection and visibility checks;
- download history visibility checks;
- missing-file 404 handling in the delivery endpoint;
- configuration tooltips and refreshed README/INSTALL/changelog;
- versioned CSS/JavaScript asset URLs using the 1.3.0 release version;
- SEO fields positioned below Detail in the download editor;
- download/category editors organized into logical sections;
- admin summary and compact status indicators;
- category file counts and enabled/disabled state in administration;
- category/status/file-health admin filters;
- targeted category status toggles with CSRF and Root checks;
- CSRF hardening for submission approval/rejection and category mutations;
- HTML/plaintext notification templates;
- collision-safe pending upload names with legacy compatibility;
- filesystem rollback when database persistence fails;
- PHP 5.6 / 8.1 / 8.3 lint matrix and clean distribution checks.

The remaining sections below are the acceptance roadmap for the release.

## Release readiness

Planned GitHub release tag: `v1.3.0` (create only after final acceptance).

### Validated on a real installation

- [x] Fresh installation
- [x] Uninstall
- [x] Plugin activation / deactivation
- [x] Upgrade from the previous Downloads version

### Functional validation still required before PR

- [x] Add / edit / replace / delete a download
- [x] Add / edit / enable / disable a category
- [x] Public search with matches and with no results
- [x] Download image and lightbox
- [x] Comments and rating
- [ ] User submission creates Pending state
- [ ] Approval through Geeklog moderation creates Published state
- [ ] Approval through Downloads administration
- [ ] Rejection creates Rejected state
- [ ] New-submission email notification
- [ ] Submitter approval email notification
- [ ] Missing physical file produces admin diagnostic and public 404
- [x] IndexNow integration
- [x] XMLSitemap downloads
- [x] XMLSitemap categories (implementation added; real regeneration test required)
- [x] Generic public 404 handling
- [x] Rich editor Preview reflects the intended public content
- [ ] Oversized upload produces a controlled user-facing error

### Public UI direction

- Public pages should keep their existing visual identity and charm.
- Prefer spacing, responsive, accessibility and small visual refinements over a wholesale redesign.
- Administration forms can be modernized more substantially because clarity and maintenance take priority there.

### Deferred from the 1.3.0 release candidate

- Multisite-safe automatic migration of persistent storage outside `public_html`.
- Default download image enhancement.
- Legacy File Manager conversion cleanup unless a reproducible 1.3.0 regression is found.



### Interoperability alignment

Downloads 1.3.0 now targets the Memorandum content interoperability contract:

- [x] Item Info for legacy download IDs
- [x] Stable root identity: `root`
- [x] Stable category identities: `category:<cid>`
- [x] Normalized subtype / is-container / parent-id fields
- [x] Normalized hits / image / category metadata for downloads
- [x] Collection filtering by subtype, including `all`
- [x] Native `plugin_collectSitemapItems_downloads()`
- [x] Correct Geeklog 2.2.2 `plugin_idToURL_downloads($sub_type, $item_id)` signature
- [x] Sitemap URL de-duplication
- [x] Category lifecycle events
- [x] Download lifecycle events on category cascade delete
- [x] `PLG_itemDisplay()` extension points on full download/root/category views
- [x] Metadata cooperation through `PLG_getMetaTags()`
- [x] Language-aware category collections

A full XMLSitemap regeneration is required after installing this build to remove duplicate rows created by the previous incorrect `idToURL` signature.


### XMLSitemap interoperability note

- XMLSitemap duplicate output was traced to duplicated `types` entries in XMLSitemap configuration, not to duplicate URLs returned by Downloads.
- Downloads itself de-duplicates its collection output.
- A separate core XMLSitemap fix is maintained in `hostellerie/geeklog-2.2.2:xmlsitemap-deduplicate-types`.
- After deploying that core fix, run a full sitemap regeneration once to remove previously persisted duplicate rows.


### Plugin configuration interoperability

- [x] Runtime configuration loading no longer leaks generic temporary globals.
- [x] Generic `ROOTID` constant replaced by `DLM_ROOTID`.
- [x] Multilingual SQL helper accepts the category table alias.
- [x] XMLSitemap/Item Info queries using alias `c` explicitly request `DLM_helper_getLangSQL('c')`.
- [x] Validate saving the configuration of another active plugin while Downloads is enabled.
